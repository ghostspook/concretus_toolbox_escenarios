import deep

ambiente = deep.nuevo_ambiente('input/plan_cuentas_concretus.xlsx')

if deep.validar_arbol(ambiente):
    print("Árbol OK")
    # root = deep.obtener_arbol(ambiente)
    # deep.imprimir_arbol(ambiente, root)


ambiente = deep.cargar_escenario(ambiente, 'input/SAENZ RONQUILLO_NOVIEMBRE_2021.xlsx')
# deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_NOVIEMBRE_2021', imprimir=True)

ambiente = deep.cargar_netos_movimientos(ambiente, 'input/SAENZ RONQUILLO_DICIEMBRE_2021_(netos_movimientos).xlsx')
# deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_DICIEMBRE_2021 (netos movimientos)', imprimir=False)
#
ambiente = deep.computar_acumulado(ambiente, 'SAENZ RONQUILLO_NOVIEMBRE_2021', 'SAENZ RONQUILLO_DICIEMBRE_2021 (netos movimientos)', 'SAENZ RONQUILLO_DICIEMBRE_2021')
deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_DICIEMBRE_2021', imprimir=True)

# ambiente = deep.minimizar(ambiente)
# ambiente.to_excel("output/SAENZ RONQUILLO_DICIEMBRE_2021.xlsx")
# print(ambiente['SAENZ RONQUILLO_DICIEMBRE_2021'])


# ----------------- 2022 -------------------

import deep

ambiente = deep.nuevo_ambiente('input/plan_cuentas_concretus.xlsx')

if deep.validar_arbol(ambiente):
    print("Árbol OK")
    # root = deep.obtener_arbol(ambiente)
    # deep.imprimir_arbol(ambiente, root)

# Parte de diciembre 2021
ambiente = deep.cargar_escenario(ambiente, 'input/SAENZ RONQUILLO_DICIEMBRE_2021.xlsx')
# deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_DICIEMBRE_2021', imprimir=True)

# Enero 2022
ambiente = deep.cargar_netos_movimientos(ambiente, 'input/SAENZ RONQUILLO_ENERO_2022 (delta).xlsx')
# deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_ENERO_2022 (delta)', imprimir=True)
#
ambiente = deep.computar_acumulado(ambiente, 'SAENZ RONQUILLO_DICIEMBRE_2021', 'SAENZ RONQUILLO_ENERO_2022 (delta)', 'SAENZ RONQUILLO_ENERO_2022', acumular_resultados_ejercicio_anterior=True)
# deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_ENERO_2022', imprimir=True)

# Febrero 2022
ambiente = deep.cargar_netos_movimientos(ambiente, 'input/SAENZ RONQUILLO_FEBRERO_2022 (delta).xlsx')
# deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_FEBRERO_2022 (delta)', imprimir=True)

ambiente = deep.computar_acumulado(ambiente, 'SAENZ RONQUILLO_ENERO_2022', 'SAENZ RONQUILLO_FEBRERO_2022 (delta)', 'SAENZ RONQUILLO_FEBRERO_2022')
# deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_FEBRERO_2022', imprimir=True)

# Marzo 2022
ambiente = deep.cargar_netos_movimientos(ambiente, 'input/SAENZ RONQUILLO_MARZO_2022 (delta).xlsx')
# deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_MARZO_2022 (delta)', imprimir=True)

ambiente = deep.computar_acumulado(ambiente, 'SAENZ RONQUILLO_FEBRERO_2022', 'SAENZ RONQUILLO_MARZO_2022 (delta)', 'SAENZ RONQUILLO_MARZO_2022')
# deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_MARZO_2022', imprimir=True)

# Abril 2022
ambiente = deep.cargar_netos_movimientos(ambiente, 'input/SAENZ RONQUILLO_ABRIL_2022 (delta).xlsx')
# deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_ABRIL_2022 (delta)', imprimir=True)

ambiente = deep.computar_acumulado(ambiente, 'SAENZ RONQUILLO_MARZO_2022', 'SAENZ RONQUILLO_ABRIL_2022 (delta)', 'SAENZ RONQUILLO_ABRIL_2022')
# deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_ABRIL_2022', imprimir=True)

# Mayo 2022
ambiente = deep.cargar_netos_movimientos(ambiente, 'input/SAENZ RONQUILLO_MAYO_2022 (delta).xlsx')
# deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_MAYO_2022 (delta)', imprimir=True)

ambiente = deep.computar_acumulado(ambiente, 'SAENZ RONQUILLO_ABRIL_2022', 'SAENZ RONQUILLO_MAYO_2022 (delta)', 'SAENZ RONQUILLO_MAYO_2022')
deep.validar_escenario(ambiente, 'SAENZ RONQUILLO_MAYO_2022', imprimir=True)

ambiente = deep.minimizar(ambiente)
# ambiente.to_excel("output/SAENZ RONQUILLO_MAYO_2022.xlsx")
# print(ambiente['SAENZ RONQUILLO_ENERO_2022'])